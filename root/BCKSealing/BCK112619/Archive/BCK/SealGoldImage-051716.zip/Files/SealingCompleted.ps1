
 
$fromaddress = "CitrixSealing@allscripts.com"
$toaddress = "TSSClientDelivery@allscripts.com"
$CitrixSender = $env:username
switch ($CitrixSender)
{
 
  "akadri"    { $toaddress="asrar.kadri@allscripts.com"}
  "vchandel"  { $toaddress="vibhvesh.chandel@allscripts.com" }
  "kmistry"   { $toaddress = "kaushal.mistry@allscripts.com"}
  "DEasterd"  {$toaddress = "Diane.Easterday@allscripts.com"}
  "jMoore1"   {$toaddress = "gerald.moore@allscripts.com"}
  "snazirmulla" {$toaddress = "sarfaraz.nazirmulla@allscripts.com"}
  "MPanicker1"  {$toaddress = "Manu.Panicker@allscripts.com"}
   "VPeters"   {$toaddress = "Vanessa.Peters@allscripts.com"}
  "CSmetters"  {$toaddress = "Craig.Smetters@allscripts.com"}
  "RSolanki"   {$toaddress = "Rohan.solanki@allscripts.com"}
  "DStewart"  {$toaddress = "Darryl.Stewart@allscripts.com"}
  "MTorres"   {$toaddress = "Marco.Torres@allscripts.com"}
  "KTyther"   {$toaddress = "Keith.Tyther@allscripts.com"}
  "dzorola"  {$toaddress = "Daniel.CuetoZorola@allscripts.com"}
  "aKhan"    {$toaddress = "Ray.Khan@allscripts.com"}
  "jpatel"   {$toaddress = "Jigneshkumar.Patel@allscripts.com"}

}





$ClientCode = 'ClientCode:' + $env:computername.Substring(0,2)
$RebootDetail = foreach($line in (Select-String -Path "\\tscmgr\SealingBatchFiles\Files\CitrixReboots.txt" -pattern $ClientCode)){$line.line}
$ClientFarm = $RebootDetail.Substring(14,1)
$ClientRebootSchedule =  $RebootDetail.Substring(16)


$key = 'HKLM:\SYSTEM\CurrentControlSet\services\bnistack\PvsAgent'
$vdiskname = (Get-ItemProperty -Path $key).DiskName

 
#################################### 

$Subject = $env:computername + " sealing completed"
$body = "<font -family: Calibri; font-size: 11pt>***Forward to appropiate parties***</font> <br><br><br>"
$body = "***Forward to appropiate parties*** <br><br>"
$body += "Sealing process completed on vdisk: <b>$vdiskname</b> , please proceed with validations then reply back to all in this email for confirmation.<br>"
$body += "Validation server: <br><br>"

$body += "FYI: Scheduled reboots detail for this client:<br><br>"
$body += "Farm: $ClientFarm<br>"
$body += "Schedule start date/time: $ClientRebootSchedule"

#$body += "Click <a href=http://www.google.com>here</a> to open google <br>"

$smtpserver = "172.30.4.18"  
$message = new-object System.Net.Mail.MailMessage 
send-MailMessage -SmtpServer $smtpserver -To $toaddress -From $fromaddress -Subject $subject -Body $body -BodyAsHtml -Priority Normal